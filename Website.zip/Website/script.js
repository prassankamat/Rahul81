document.getElementById("salaryForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("empName").value;
  const designation = document.getElementById("designation").value;
  const basic = parseFloat(document.getElementById("basic").value);
  const hra = parseFloat(document.getElementById("hra").value);
  const da = parseFloat(document.getElementById("da").value);
  const others = parseFloat(document.getElementById("others").value);
  const deductions = parseFloat(document.getElementById("deductions").value);

  const gross = basic + hra + da + others;
  const net = gross - deductions;

  const table = document.querySelector("#salaryTable tbody");
  const row = table.insertRow();

  row.innerHTML = `
    <td>${name}</td>
    <td>${designation}</td>
    <td>${basic.toFixed(2)}</td>
    <td>${hra.toFixed(2)}</td>
    <td>${da.toFixed(2)}</td>
    <td>${others.toFixed(2)}</td>
    <td>${gross.toFixed(2)}</td>
    <td>${deductions.toFixed(2)}</td>
    <td>${net.toFixed(2)}</td>
  `;

  // Clear form
  document.getElementById("salaryForm").reset();
});

document.getElementById("exportBtn").addEventListener("click", function () {
  let csv = [];
  const rows = document.querySelectorAll("table tr");
  rows.forEach(row => {
    const cols = Array.from(row.querySelectorAll("td, th")).map(cell => `"${cell.innerText}"`);
    csv.push(cols.join(","));
  });

  const blob = new Blob([csv.join("\n")], { type: "text/csv" });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.setAttribute("href", url);
  a.setAttribute("download", "salary_register.csv");
  a.click();
});
